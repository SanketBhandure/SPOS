public class Sheduling{
	Scanner	
}
public static void main(String []arg){
}
