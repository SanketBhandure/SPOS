import java.util.*;

public class process {
	public int pid;
	public int bt;
	public int wt=0;
	public int tat;
	public int at;
	public int pri;
	public int rt;
}
